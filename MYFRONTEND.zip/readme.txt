################################################################################################

IT Worker Template by Bootstrapious -  https://bootstrapious.com

################################################################################################

Hi,

thank you for downloading. Have fun and tell your friends about us ;)

Ondrej, Bootstrapious


CSS
----------

The theme stylesheet is css/style.default.css. If you want to make any changes, 
you can do it here or better to override it in custom.css so you can update the original theme stylesheet if an updated is released. 
Changing to another colour variant, is just a matter of replacing css/style.default.css with css/style.pink.css in index.html.

Javascript
----------

Apart from the Bootstrap JS components, the majority of JS is located in /js/front.js. 


Credits
---------

- Botstrap 4 - http://getbootstrap.com
- Font Awesome 4.7 - http://fontawesome.io/
- Google Fonts - Roboto, Roboto Slab
- more in credits.txt.

Changelog
---------

-----------------------------------------------------------------------------------------
Version 2.1 - 2019/03/01
-----------------------------------------------------------------------------------------
    
- updated Bootstrap to 4.3.1
- dropped Google Maps, replaced by free OpenStreetMaps + LeafletJs

-----------------------------------------------------------------------------------------
Version 2.0.1 - 2018/10/29
-----------------------------------------------------------------------------------------
    
- removed style switcher that should be only in the demo version, not in the distribution
  package
- updated: Animate.css, Bootstrap, Owl Carousel, PopperJs

-----------------------------------------------------------------------------------------
Version 2.0.0 - 2018/06/19
-----------------------------------------------------------------------------------------
    
- a complete rework into Boostrap 4.1.1
- removed PHP form

-----------------------------------------------------------------------------------------
Version 1.1 - 2017/10/10
-----------------------------------------------------------------------------------------

- minor fixes

-----------------------------------------------------------------------------------------
Version 1.3 - 2015/02/02
-----------------------------------------------------------------------------------------

- Initial release

---------------------
 LICENSE CONDITIONS
---------------------

You are completely free to use this template for your personal use or as a work for your client as 
long as you keep the link at the template footer pointing to us and our partner. 

If you would prefer removing the backlink from the theme footer, please donate (https://bootstrapious.com/donate) 
to support themes' development. Suggested amount per template is $10. 
Also, as a bonus for donors, I can provide you the SASS files for even easier template customization. Drop me a line at hello@bootstrapious.com after donating.

However you cannot redistribute the template nor its derivatives on the internet - neither for free or commercially (e.g. selling it on template marketplace).

Thank you for understanding and respecting the license conditions.

---------------------
 GET IN TOUCH ;)
---------------------

https://twitter.com/bootstrapious | https://google.com/+Bootstrapious1 | https://www.facebook.com/bootstrapious | hello@bootstrapious.com
